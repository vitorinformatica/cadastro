package trabalho;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author vitor
 */
public class Entrega {
    private int codigo;
    private int cod_remetente;
     private int cod_destinatario;
      private int cod_entregador;
       private int valor_entrega;

    public Entrega() {
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCod_remetente() {
        return cod_remetente;
    }

    public void setCod_remetente(int cod_remetente) {
        this.cod_remetente = cod_remetente;
    }

    public int getCod_destinatario() {
        return cod_destinatario;
    }

    public void setCod_destinatario(int cod_destinatario) {
        this.cod_destinatario = cod_destinatario;
    }

    public int getCod_entregador() {
        return cod_entregador;
    }

    public void setCod_entregador(int cod_entregador) {
        this.cod_entregador = cod_entregador;
    }

    public int getValor_entrega() {
        return valor_entrega;
    }

    public void setValor_entrega(int valor_entrega) {
        this.valor_entrega = valor_entrega;
    }
       
       
}
