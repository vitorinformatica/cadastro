package trabalho;


import java.sql.DriverManager;
import java.sql.SQLException;





public class Connection {
    
    //static define que existira para todas instancia da classe final define valor nao pode ser alterado
  private  static final String user= "root";
    private static final String senha= "vitor2020";
    private static final String url = "jdbc:mysql://127.0.0.1:3306/java";
    private static final String driver = "com.mysql.jdbc.Driver";

    // Conectar ao banco
    public static Connection abrir() throws Exception {
        // Registrar o driver
        Class.forName(driver);
        
// Capturar a conexão

        
// Retorna a conexao aberta
        return conn;


    }   
}